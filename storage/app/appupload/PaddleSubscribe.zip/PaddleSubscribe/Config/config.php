<?php

return [
    'name' => 'PaddleSubscribe',
    'paddlevendorid'=>env('paddleVendorID',''),
];
