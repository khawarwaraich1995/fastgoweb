<?php

return [
    'name' => 'PdfInvoice',
    'invoiceTitle' => env('pdf_invoice_title',"Order")
];
