<?php

return [

    'name'              => 'Paystack',
    'description'       => 'This is my awesome module',

];