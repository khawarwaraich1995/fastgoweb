<?php

return [

    'name'              => 'Impressum',
    'description'       => 'This is my awesome module',

];