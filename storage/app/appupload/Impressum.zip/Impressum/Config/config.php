<?php

return [
    'name' => 'Impressum'
];
