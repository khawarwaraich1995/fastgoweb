<?php

return [

    'name'              => 'Razorpay',
    'description'       => 'This is my awesome module',

];